﻿namespace Raiding
{
    public abstract class HeroCreator
    {
        public abstract BaseHero GetHero();
    }
}
